import { createSlice } from "@reduxjs/toolkit";

const cartSlice=createSlice({
    name:'cart',
    initialState:[],
    reducers:{
        add:(state,action) => {
            state.push(action.payload);
        },
        remove:(state,action) => {
            return state.filter(item => item.id !== action.payload);
        },
        increment(state, action) {
            let date = state.find((item) => item.id === action.payload)
            if (date) {
              date.quantity += 1
            }
          },
          decrement(state, action) {
            let items = state.find((item) => item.id === action.payload)
            if (items && items.quantity >1) {
              items.quantity -= 1
            }
          },
          clearCart: () => {
            return [];
          },
    },
});

export const{add,remove,increment,decrement,clearCart}=cartSlice.actions;
export default cartSlice.reducer;