
import { configureStore } from '@reduxjs/toolkit';
import cartred from './Cartslice';

const store = configureStore({
  reducer: {
    cart: cartred
  }
});

export default store;




