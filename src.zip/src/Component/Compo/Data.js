import React, { useCallback } from "react";
import OwlCarousel from "react-owl-carousel";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";
import { add } from '../store/Cartslice';
import { useSelector, useDispatch } from 'react-redux';
import Datadetails from '../Compo/Datadetails';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Data = () => {
  const cartItems = useSelector((state) => state.cart); // Get cart items from Redux state
  const dispatch = useDispatch();

  // const handleAdd = useCallback((item) => {
  //   const isAlreadyInCart = cartItems.find((cartItems) => cartItems.id === item.id);

  //   if (!isAlreadyInCart) {
  //     dispatch(add(item));
  //     // toast.success("Item successfully added to cart!");
  //   } else {
  //     // toast.error("This item is already in your cart.");
  //     alert("suucessfully added.😍")
  //   }
  // }, [cartItems, dispatch]);


  const handleAdd = (item) => {
    const isAlreadyInCart = cartItems.find((cartItem) => cartItem.id == item.id);
console.log(isAlreadyInCart,"count")
    if (!isAlreadyInCart) {
      dispatch(add(item));
      // toast.success("Item successfully added to cart!");
    } else {
      // toast.error("This item is already in your cart.");
      alert("suucessfully added.😍")
    }
  };

  const carouselOptions = {
    items: 1,
    loop: true,
    autoplay: true,
    autoplayTimeout: 4000,
    center: false,
    dots: false,
    nav: false,
    margin: 10,
    responsiveClass: true,
    responsive: {
      0: { items: 1 },
      600: { items: 2 },
      1000: { items: 4 },
    },
  };

  return (
    <div id="Product" className="product-container">
      <div className="center">
        <div className="ddd"></div>
        <h1>
          <span>Special Products</span>
        </h1>
      </div>
      <div className="ddd"></div>
      <OwlCarousel className="owl-theme" {...carouselOptions}>
        {Datadetails.map((item) => {
          // const isAlreadyInCart1 = cartItems.some((cartItem1) => cartItem1.id === item.id); // Check if item is already in cart

          return (
            <div className="item" key={item.id}>
              <div className="card product-card">
                <img src={item.img} className="card-img-top product-img" alt={item.name} />
                <div className="card-body">
                  <h4 className="card-title">{item.name}</h4>
                  <div className="price-time d-flex justify-content-between">
                    <h5>Rs. {item.price}</h5>
                    <div>{item.time} Min</div>
                  </div>
                  <button
                    // className={`btn mt-3 add-to-cart-btn 
                    //   ${isAlreadyInCart1 ? 'btn-success' : 'btn-primary'}`}
                    // disabled={isAlreadyInCart1} // Disable button if item is already in the cart
                    onClick={() => handleAdd(item)} // Use handleAdd function
                  >
                    {/* {isAlreadyInCart1 ? 'Added to Cart' : 'Add to Cart'} */}
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </OwlCarousel>
      <ToastContainer />
    </div>
  );
};

export default Data;
