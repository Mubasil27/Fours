import img1 from "../Image/sandwich-5930496.jpg"
import img2 from "../Image/ai-generated-8711272.jpg"
import img3 from "../Image/a1e1c70b020f0e005e3dd3c154dd006f.avif"
import img4 from "../Image/09b13b12ab26583cd29cf6055c9cc3cf.avif"
import img5 from "../Image/2fca38ab7be6bfe27b31ca784d95c0d6_o2_featured_v2.avif"
import img6 from "../Image/c04c82806e654ca0c358a1ce33463da6.avif"
import img7 from "../Image/40610166bbb9d0112675883acf9e2ded.avif"
import img8 from "../Image/09e7e40ef2591f14cf7649dfe2a4fddf_o2_featured_v2.avif"
import img9 from "../Image/eb571af2074d087a9c3a224142b77e7b.webp"
import img10 from "../Image/1095bb4df797955f0785e3a87579824c.avif"
import img11 from "../Image/a31403b412e0abefa38d198b590fe860.avif"
import img12 from "../Image/022b45dcd1d76df7d990c7e60e8b651c.avif"

let Data=[
    {
        "id":1,
        "name":"Cheese Blast  Burger",
        "price":169,
        "img":img1,
        "desc":"Experience our Cheese Blast Patty with Crunchy, spicy crushed aloo spuds, topped with onion rings, spicy chipotle and creamy mayo and in between soft classic buns. Add some zing to your burger cravings and get your spice on.",

        "time":40

    },{
        "id":2,
        "name":"Greek Pizza",
        "price":289,
        "img":img2,
        "time":25,
        "desc":"Spiced paneer, crunchy onion, juicy tomato & 100% mozzarella cheese, with our classic pan sauce (PAN Per/Med-276 Kcal/100g | TnC-283 Kcal/100g | Stuffed Crust Add : Per: 227 Kcal/100g | Med: 216 Kcal/100g). Contains Cereals containing Gluten (Wheat), Soya and Milk & Milk Products."



    },{
        "id":3,
        "name":"Grilled Sandwich",
        "price":190,
        "img":img3,
        "time":15,
        "desc":"Cheesy & Crunchy. Layered with our special green chutney. Served With Our Signature Mayochop Sauce. 200 gm serving. 250 Kcal / 100 gm."



    },
    {
        "id":4,
        "name":"Tandoori Chicken",
        "price": 299,
        "img":img4,
        "time":30,
        "desc":"Soft Tender Marinated Chicken Pieces, Roasted In Hot Clay Oven And Cooked To Perfection. | Served With Bones | | Served With Salad"

    },{
        "id":5,
        "name":"Masala Dosa",
        "price":139,
        "img":img5,
        "time":22,
        "desc":"Dosa Filled With Aloo Masala And Topped With Onions. Served With One Portion Of Sambhar, Coconut Chutney And Tomato Chutney."


    },
    {
        "id":6,
        "name":"Cheesy Paneer Wrap",
        "price":189,
        "img":img6,
        "time":10,
        "desc":"Spice up your taste buds with our Paneer Manchurian Frankie - loaded with juicy paneer bites, zesty Manchurian balls, and fresh veggies wrapped in a warm and fluffy frankie roll!"


    },
    {
        "id":7,
        "name":"Kaju Anjeer Shake",
        "price":390,
        "img":img7,
        "time":20,
        "desc":"kaju anjeer shake, tasty and thick milkshake. Suitable for fasting [upwas]. No added preservatives, colors, chemicals and flavours."


    },
    {
        "id":8,
        "name":"Afghani Biryani ",
        "price":249,
        "img":img8,
        "time":30,
        "desc":"Legendary for its rich taste & creamy texture, tender chicken marinated in fresh creamy yoghurt & spices is layered with aromatic basmati."

    },
    {
        "id":9,
        "name":"Italiano Pasta",
        "price":249,
        "img":img9,
        "time":20,
        "desc":"An Italian classic with an india twist. Onion, capsicum, paneer, mushroom."

    },
    {
        "id":10,
        "name":"Mango  Pastry",
        "price":149,
        "img":img10,
        "time":15,
        "desc":"Three layers of Mango mousse: white, milk and dark chocolate mousse."

    },
    {
        "id":11,
        "name":"Chocolate ice cream",
        "price":990,
        "img":img11,
        "time":5,
        "desc":"chocolate ice cream with a distinct hint of cocoa. The mother of every chocolate ice cream creation of ours."

    },{
        "id":12,
        "name":"Paneer Tikka",
        "price":90,
        "img":img12,

        "time":15,
        "desc":"An Innovation To Our Paneer Pudina Tikka - Savour The Soft And Smooth Chunks Of Smokey Chutney Stuffed Paneer Tikka"

    },
]

Data=Data.map(item=>({...item,quantity:1}))
console.log(Data,"djk");
 
    

    // let Burger=[
    
    // {
    //     id: 13,
    //     name: "Spicy Chicken Burger",
    //     price: 189,
    //     img: "img2",
    //     desc: "A juicy chicken patty coated with our special spicy seasoning, paired with lettuce, tomato, and chipotle mayo in a toasted sesame bun.",
    //     time: 30
    //   },
    //   {
    //     id: 14,
    //     name: "Classic Veggie Burger",
    //     price: 149,
    //     img: "img3",
    //     desc: "A classic veggie patty made from fresh vegetables, served with lettuce, tomato, onion, and a dash of mayo in a whole wheat bun.",
    //     time: 25
    //   },
    
    // ]
    export default Data
    
   


    // let deta=[
    //     {
    //         id: 1,
    //         name: "Cheese Blast Burger",
    //         price: 169,
    //         img: "img1", // Replace with the correct image path
    //         desc: "Experience our Cheese Blast Patty with Crunchy, spicy crushed aloo spuds, topped with onion rings, spicy chipotle, and creamy mayo between soft classic buns. Add some zing to your burger cravings.",
    //         time: 40
    //       },
        //   {
        //     id: 2,
        //     name: "Spicy Chicken Burger",
        //     price: 189,
        //     img: "img2",
        //     desc: "A juicy chicken patty coated with our special spicy seasoning, paired with lettuce, tomato, and chipotle mayo in a toasted sesame bun.",
        //     time: 30
        //   },
        //   {
        //     id: 3,
        //     name: "Classic Veggie Burger",
        //     price: 149,
        //     img: "img3",
        //     desc: "A classic veggie patty made from fresh vegetables, served with lettuce, tomato, onion, and a dash of mayo in a whole wheat bun.",
        //     time: 25
        //   },
    //       {
    //         id: 4,
    //         name: "BBQ Beef Burger",
    //         price: 249,
    //         img: "img4",
    //         desc: "Tender beef patty glazed with BBQ sauce, topped with caramelized onions, lettuce, and cheddar cheese, served in a toasted brioche bun.",
    //         time: 35
    //       },
    //       {
    //         id: 5,
    //         name: "Double Cheese Beef Burger",
    //         price: 299,
    //         img: "img5",
    //         desc: "Two juicy beef patties, double cheddar cheese, lettuce, tomato, and special sauce in a fluffy bun. Perfect for cheese lovers!",
    //         time: 40
    //       },
    //       {
    //         id: 6,
    //         name: "Tandoori Paneer Burger",
    //         price: 199,
    //         img: "img6",
    //         desc: "Grilled paneer marinated in tandoori spices, layered with lettuce, onions, and mint chutney in a soft bun.",
    //         time: 20
    //       },
    //       {
    //         id: 7,
    //         name: "Crispy Fish Burger",
    //         price: 219,
    //         img: "img7",
    //         desc: "Crispy fish fillet topped with tartar sauce, fresh lettuce, and pickles served in a steamed bun. A true catch!",
    //         time: 28
    //       },
    //       {
    //         id: 8,
    //         name: "Mushroom Swiss Burger",
    //         price: 229,
    //         img: "img8",
    //         desc: "Juicy beef patty with sautéed mushrooms, Swiss cheese, and garlic mayo in a buttered toasted bun.",
    //         time: 32
    //       },
    //       {
    //         id: 9,
    //         name: "Pulled Pork BBQ Burger",
    //         price: 259,
    //         img: "img9",
    //         desc: "Slow-cooked pulled pork in BBQ sauce, topped with coleslaw and pickles in a soft brioche bun.",
    //         time: 45
    //       },
    //       {
    //         id: 10,
    //         name: "Peri-Peri Chicken Burger",
    //         price: 179,
    //         img: "img10",
    //         desc: "Spicy peri-peri grilled chicken breast, with lettuce, tomato, and garlic aioli, served in a crispy ciabatta roll.",
    //         time: 30
    //       },
    //       {
    //         id: 11,
    //         name: "Bacon & Cheese Burger",
    //         price: 279,
    //         img: "img11",
    //         desc: "A smoky beef patty with crispy bacon, melted cheddar, lettuce, and tomato in a toasted sesame seed bun.",
    //         time: 35
    //       },
    //       {
    //         id: 12,
    //         name: "Falafel Burger",
    //         price: 159,
    //         img: "img12",
    //         desc: "Crispy falafel patty, served with hummus, lettuce, tomato, and cucumber in a whole grain bun.",
    //         time: 20
    //       },
    //       {
    //         id: 13,
    //         name: "Blue Cheese Beef Burger",
    //         price: 269,
    //         img: "img13",
    //         desc: "Beef patty topped with tangy blue cheese, caramelized onions, and arugula in a toasted ciabatta bun.",
    //         time: 37
    //       },
    //       {
    //         id: 14,
    //         name: "Hawaiian Chicken Burger",
    //         price: 199,
    //         img: "img14",
    //         desc: "Grilled chicken breast with grilled pineapple, teriyaki sauce, lettuce, and mayo in a soft bun.",
    //         time: 25
    //       },
    //       {
    //         id: 15,
    //         name: "Chipotle Black Bean Burger",
    //         price: 179,
    //         img: "img15",
    //         desc: "Spicy black bean patty with avocado, chipotle mayo, lettuce, and tomato in a soft whole wheat bun.",
    //         time: 25
    //       },
    //       {
    //         id: 1,
    //         name: "Margherita Pizza",
    //         price: 249,
    //         img: "img1", // Replace with actual image path
    //         time: 20,
    //         desc: "A simple classic, made with 100% mozzarella cheese, fresh tomato sauce, and oregano on a thin crust base."
    //       },
    //       {
    //         id: 2,
    //         name: "Pepperoni Pizza",
    //         price: 299,
    //         img: "img2", // Replace with actual image path
    //         time: 25,
    //         desc: "A favorite among meat lovers, topped with spicy pepperoni and mozzarella cheese."
    //       },
    //       {
    //         id: 3,
    //         name: "BBQ Chicken Pizza",
    //         price: 329,
    //         img: "img3", // Replace with actual image path
    //         time: 30,
    //         desc: "Grilled chicken, BBQ sauce, red onions, and cilantro over mozzarella cheese."
    //       },
    //       {
    //         id: 4,
    //         name: "Hawaiian Pizza",
    //         price: 279,
    //         img: "img4", // Replace with actual image path
    //         time: 25,
    //         desc: "A tropical delight with ham, pineapple, and mozzarella cheese."
    //       },
    //       {
    //         id: 5,
    //         name: "Veggie Supreme Pizza",
    //         price: 299,
    //         img: "img5", // Replace with actual image path
    //         time: 20,
    //         desc: "Loaded with bell peppers, onions, mushrooms, and olives over a rich tomato sauce."
    //       },
    //       {
    //         id: 6,
    //         name: "Meat Lovers Pizza",
    //         price: 349,
    //         img: "img6", // Replace with actual image path
    //         time: 30,
    //         desc: "A carnivore's dream with pepperoni, sausage, bacon, and ham topped with mozzarella."
    //       },
    //       {
    //         id: 7,
    //         name: "Four Cheese Pizza",
    //         price: 329,
    //         img: "img7", // Replace with actual image path
    //         time: 25,
    //         desc: "A cheesy delight with mozzarella, cheddar, parmesan, and gorgonzola."
    //       },
    //       {
    //         id: 8,
    //         name: "Buffalo Chicken Pizza",
    //         price: 319,
    //         img: "img8", // Replace with actual image path
    //         time: 30,
    //         desc: "Spicy buffalo chicken, blue cheese dressing, and mozzarella cheese."
    //       },
    //       {
    //         id: 9,
    //         name: "Spinach and Feta Pizza",
    //         price: 289,
    //         img: "img9", // Replace with actual image path
    //         time: 20,
    //         desc: "Fresh spinach, feta cheese, and mozzarella topped with a drizzle of olive oil."
    //       },
    //       {
    //         id: 10,
    //         name: "Pesto Veggie Pizza",
    //         price: 299,
    //         img: "img10", // Replace with actual image path
    //         time: 25,
    //         desc: "Pesto sauce, fresh veggies, and mozzarella cheese on a thin crust."
    //       },
    //       {
    //         id: 11,
    //         name: "Tandoori Chicken Pizza",
    //         price: 329,
    //         img: "img11", // Replace with actual image path
    //         time: 30,
    //         desc: "Tandoori chicken pieces, onions, and capsicum on a spicy sauce base."
    //       },
    //       {
    //         id: 12,
    //         name: "Seafood Pizza",
    //         price: 399,
    //         img: "img12", // Replace with actual image path
    //         time: 35,
    //         desc: "A mix of shrimp, squid, and clams on a rich tomato sauce with mozzarella."
    //       },
    //       {
    //         id: 13,
    //         name: "Greek Pizza",
    //         price: 289,
    //         img: "img13", // Replace with actual image path
    //         time: 25,
    //         desc: "Topped with olives, feta cheese, red onions, and fresh tomatoes."
    //       },
    //       {
    //         id: 14,
    //         name: "Caprese Pizza",
    //         price: 299,
    //         img: "img14", // Replace with actual image path
    //         time: 20,
    //         desc: "Fresh mozzarella, tomatoes, basil, and a drizzle of balsamic glaze."
    //       },
    //       {
    //         id: 15,
    //         name: "Buffalo Veggie Pizza",
    //         price: 299,
    //         img: "img15", // Replace with actual image path
    //         time: 25,
    //         desc: "Buffalo sauce, fresh vegetables, and mozzarella cheese for a spicy kick."
    //       },{
    //         id: 1,
    //         name: "Grilled Sandwich",
    //         price: 190,
    //         img: img1, // Replace with actual image path
    //         time: 15,
    //         desc: "Cheesy & Crunchy. Layered with our special green chutney. Served with our signature Mayochop Sauce. 200 gm serving. 250 Kcal / 100 gm."
    //       },
    //       {
    //         id: 2,
    //         name: "Club Sandwich",
    //         price: 250,
    //         img: img2, // Replace with actual image path
    //         time: 20,
    //         desc: "A triple-layer sandwich with turkey, bacon, lettuce, tomato, and mayonnaise. Served with fries."
    //       },
    //       {
    //         id: 3,
    //         name: "Veggie Delight Sandwich",
    //         price: 180,
    //         img: img3, // Replace with actual image path
    //         time: 10,
    //         desc: "Fresh veggies, cheese, and hummus in whole grain bread."
    //       },
    //       {
    //         id: 4,
    //         name: "Chicken Caesar Sandwich",
    //         price: 220,
    //         img: img4, // Replace with actual image path
    //         time: 15,
    //         desc: "Grilled chicken, romaine lettuce, and Caesar dressing in a toasted baguette."
    //       },
    //       {
    //         id: 5,
    //         name: "Tuna Melt Sandwich",
    //         price: 210,
    //         img: img5, // Replace with actual image path
    //         time: 15,
    //         desc: "Creamy tuna salad topped with melted cheese on grilled bread."
    //       },
    //       {
    //         id: 6,
    //         name: "Pesto Chicken Sandwich",
    //         price: 240,
    //         img: img6, // Replace with actual image path
    //         time: 20,
    //         desc: "Grilled chicken breast with pesto sauce, sun-dried tomatoes, and mozzarella cheese."
    //       },
    //       {
    //         id: 7,
    //         name: "Buffalo Chicken Sandwich",
    //         price: 230,
    //         img: img7, // Replace with actual image path
    //         time: 15,
    //         desc: "Fried chicken tossed in spicy buffalo sauce with blue cheese dressing and lettuce."
    //       },
    //       {
    //         id: 8,
    //         name: "Caprese Sandwich",
    //         price: 200,
    //         img: img8, // Replace with actual image path
    //         time: 10,
    //         desc: "Fresh mozzarella, tomatoes, basil, and balsamic glaze on ciabatta bread."
    //       },
    //       {
    //         id: 9,
    //         name: "Egg Salad Sandwich",
    //         price: 170,
    //         img: img9, // Replace with actual image path
    //         time: 10,
    //         desc: "Creamy egg salad with lettuce on toasted bread."
    //       },
    //       {
    //         id: 10,
    //         name: "Philly Cheese Steak Sandwich",
    //         price: 260,
    //         img: img10, // Replace with actual image path
    //         time: 20,
    //         desc: "Sliced beef, sautéed onions, and melted cheese in a hoagie roll."
    //       },
    //       {
    //         id: 11,
    //         name: "Falafel Wrap",
    //         price: 190,
    //         img: img11, // Replace with actual image path
    //         time: 15,
    //         desc: "Crispy falafel balls, lettuce, and tahini sauce wrapped in pita."
    //       },
    //       {
    //         id: 12,
    //         name: "Roast Beef Sandwich",
    //         price: 240,
    //         img: img12, // Replace with actual image path
    //         time: 15,
    //         desc: "Tender roast beef with horseradish sauce and Swiss cheese on a hoagie."
    //       },
    //       {
    //         id: 13,
    //         name: "Hummus & Veggie Sandwich",
    //         price: 180,
    //         img: img13, // Replace with actual image path
    //         time: 10,
    //         desc: "Creamy hummus spread with assorted fresh veggies on whole wheat bread."
    //       },
    //       {
    //         id: 14,
    //         name: "Steak Sandwich",
    //         price: 280,
    //         img: img14, // Replace with actual image path
    //         time: 25,
    //         desc: "Grilled steak with sautéed mushrooms, onions, and cheese on a crusty roll."
    //       },
    //       {
    //         id: 15,
    //         name: "Spicy Chicken Sandwich",
    //         price: 220,
    //         img: img15, // Replace with actual image path
    //         time: 20,
    //         desc: "Crispy chicken breast with spicy mayo, lettuce, and tomato."
    //       },
    //       {
    //         id: 1,
    //         name: "Tandoori Chicken",
    //         price: 299,
    //         img: img1, // Replace with actual image path
    //         time: 30,
    //         desc: "Soft tender marinated chicken pieces, roasted in hot clay oven and cooked to perfection. Served with bones and a side of salad."
    //       },
    //       {
    //         id: 2,
    //         name: "Tandoori Leg Piece",
    //         price: 320,
    //         img: img2, // Replace with actual image path
    //         time: 35,
    //         desc: "Juicy leg piece marinated with spices and yogurt, grilled until golden brown."
    //       },
    //       {
    //         id: 3,
    //         name: "Tandoori Chicken Wings",
    //         price: 250,
    //         img: img3, // Replace with actual image path
    //         time: 25,
    //         desc: "Crispy chicken wings marinated in tandoori spices, served with mint chutney."
    //       },
    //       {
    //         id: 4,
    //         name: "Butter Chicken Tandoori",
    //         price: 350,
    //         img: img4, // Replace with actual image path
    //         time: 40,
    //         desc: "Succulent pieces of tandoori chicken simmered in rich butter gravy. Served with naan."
    //       },
    //       {
    //         id: 5,
    //         name: "Tandoori Chicken Biryani",
    //         price: 399,
    //         img: img5, // Replace with actual image path
    //         time: 45,
    //         desc: "Fragrant basmati rice layered with tandoori chicken and spices, served with raita."
    //       },
    //       {
    //         id: 6,
    //         name: "Tandoori Chicken Pizza",
    //         price: 350,
    //         img: img6, // Replace with actual image path
    //         time: 30,
    //         desc: "Thin crust pizza topped with tandoori chicken, cheese, and bell peppers."
    //       },
    //       {
    //         id: 7,
    //         name: "Tandoori Chicken Salad",
    //         price: 280,
    //         img: img7, // Replace with actual image path
    //         time: 20,
    //         desc: "Grilled tandoori chicken served on a bed of fresh greens with a tangy dressing."
    //       },
    //       {
    //         id: 8,
    //         name: "Tandoori Chicken Wrap",
    //         price: 270,
    //         img: img8, // Replace with actual image path
    //         time: 15,
    //         desc: "Tandoori chicken wrapped in soft naan with veggies and sauce."
    //       },
    //       {
    //         id: 9,
    //         name: "Tandoori Chicken Tikka",
    //         price: 320,
    //         img: img9, // Replace with actual image path
    //         time: 30,
    //         desc: "Marinated chicken pieces grilled to perfection, served with mint chutney."
    //       },
    //       {
    //         id: 10,
    //         name: "Tandoori Chicken Burger",
    //         price: 310,
    //         img: img10, // Replace with actual image path
    //         time: 20,
    //         desc: "Spicy tandoori chicken patty topped with lettuce and sauce in a soft bun."
    //       },
    //       {
    //         id: 11,
    //         name: "Tandoori Chicken Pasta",
    //         price: 340,
    //         img: img11, // Replace with actual image path
    //         time: 30,
    //         desc: "Pasta tossed with tandoori chicken, veggies, and a creamy sauce."
    //       },
    //       {
    //         id: 12,
    //         name: "Tandoori Chicken Quesadilla",
    //         price: 300,
    //         img: img12, // Replace with actual image path
    //         time: 25,
    //         desc: "Flour tortilla filled with tandoori chicken and cheese, grilled until crispy."
    //       },
    //       {
    //         id: 13,
    //         name: "Tandoori Chicken Rice Bowl",
    //         price: 290,
    //         img: img13, // Replace with actual image path
    //         time: 30,
    //         desc: "A bowl of steamed rice topped with tandoori chicken and curry sauce."
    //       },
    //       {
    //         id: 14,
    //         name: "Tandoori Chicken Skewers",
    //         price: 330,
    //         img: img14, // Replace with actual image path
    //         time: 30,
    //         desc: "Grilled skewers of marinated tandoori chicken, served with dipping sauce."
    //       },
    //       {
    //         id: 15,
    //         name: "Tandoori Chicken Naan",
    //         price: 240,
    //         img: img15, // Replace with actual image path
    //         time: 15,
    //         desc: "Soft naan bread stuffed with spiced tandoori chicken filling."
    //       },
    //       {
    //         id: 1,
    //         name: "Masala Dosa",
    //         price: 139,
    //         img: img1, // Replace with actual image path
    //         time: 22,
    //         desc: "Dosa filled with aloo masala and topped with onions. Served with sambhar, coconut chutney, and tomato chutney."
    //       },
    //       {
    //         id: 2,
    //         name: "Plain Dosa",
    //         price: 99,
    //         img: img2, // Replace with actual image path
    //         time: 20,
    //         desc: "Crispy and golden brown dosa made from fermented rice and lentil batter."
    //       },
    //       {
    //         id: 3,
    //         name: "Onion Dosa",
    //         price: 149,
    //         img: img3, // Replace with actual image path
    //         time: 22,
    //         desc: "Dosa topped with finely chopped onions and spices, served with chutney."
    //       },
    //       {
    //         id: 4,
    //         name: "Cheese Dosa",
    //         price: 169,
    //         img: img4, // Replace with actual image path
    //         time: 25,
    //         desc: "Dosa filled with a generous amount of melted cheese, served with chutney."
    //       },
    //       {
    //         id: 5,
    //         name: "Rawa Dosa",
    //         price: 159,
    //         img: img5, // Replace with actual image path
    //         time: 20,
    //         desc: "Crispy dosa made from semolina, served with sambhar and chutney."
    //       },
    //       {
    //         id: 6,
    //         name: "Paneer Dosa",
    //         price: 199,
    //         img: img6, // Replace with actual image path
    //         time: 30,
    //         desc: "Dosa stuffed with spiced paneer filling, served with chutney."
    //       },
    //       {
    //         id: 7,
    //         name: "Spinach Dosa",
    //         price: 179,
    //         img: img7, // Replace with actual image path
    //         time: 25,
    //         desc: "Dosa made with spinach batter, served with sambhar and chutney."
    //       },
    //       {
    //         id: 8,
    //         name: "Methi Dosa",
    //         price: 159,
    //         img: img8, // Replace with actual image path
    //         time: 22,
    //         desc: "Dosa made with fenugreek leaves, served with coconut chutney."
    //       },
    //       {
    //         id: 9,
    //         name: "Masala Rawa Dosa",
    //         price: 169,
    //         img: img9, // Replace with actual image path
    //         time: 30,
    //         desc: "Crispy rawa dosa filled with spicy potato masala."
    //       },
    //       {
    //         id: 10,
    //         name: "Pesarattu Dosa",
    //         price: 179,
    //         img: img10, // Replace with actual image path
    //         time: 25,
    //         desc: "Green gram dosa served with ginger chutney."
    //       },
    //       {
    //         id: 11,
    //         name: "Dahi Dosa",
    //         price: 189,
    //         img: img11, // Replace with actual image path
    //         time: 22,
    //         desc: "Dosa made with curd batter, served with chutney."
    //       },
    //       {
    //         id: 12,
    //         name: "Schezwan Dosa",
    //         price: 199,
    //         img: img12, // Replace with actual image path
    //         time: 30,
    //         desc: "Spicy dosa filled with schezwan sauce and vegetables."
    //       },
    //       {
    //         id: 13,
    //         name: "Masala Chutney Dosa",
    //         price: 179,
    //         img: img13, // Replace with actual image path
    //         time: 25,
    //         desc: "Dosa served with a spicy masala chutney."
    //       },
    //       {
    //         id: 14,
    //         name: "Vegetable Dosa",
    //         price: 169,
    //         img: img14, // Replace with actual image path
    //         time: 30,
    //         desc: "Dosa filled with mixed vegetables and spices, served with chutney."
    //       },
    //       {
    //         id: 15,
    //         name: "Kara Dosa",
    //         price: 159,
    //         img: img15, // Replace with actual image path
    //         time: 20,
    //         desc: "Spicy dosa with chilies and spices, served with coconut chutney."
    //       },{
    //         id: 1,
    //         name: "Cheesy Paneer Wrap",
    //         price: 189,
    //         img: img1, // Replace with actual image path
    //         time: 10,
    //         desc: "Spice up your taste buds with our Paneer Manchurian Frankie - loaded with juicy paneer bites, zesty Manchurian balls, and fresh veggies wrapped in a warm and fluffy frankie roll!"
    //       },
    //       {
    //         id: 2,
    //         name: "Spicy Chicken Wrap",
    //         price: 199,
    //         img: img2, // Replace with actual image path
    //         time: 12,
    //         desc: "Grilled chicken marinated in spicy sauces, wrapped with fresh veggies and tangy sauce."
    //       },
    //       {
    //         id: 3,
    //         name: "Veggie Delight Wrap",
    //         price: 159,
    //         img: img3, // Replace with actual image path
    //         time: 8,
    //         desc: "A mix of fresh vegetables and flavorful sauces, wrapped in a soft tortilla."
    //       },
    //       {
    //         id: 4,
    //         name: "Tandoori Chicken Wrap",
    //         price: 249,
    //         img: img4, // Replace with actual image path
    //         time: 15,
    //         desc: "Juicy tandoori chicken pieces wrapped with onions, lettuce, and mint sauce."
    //       },
    //       {
    //         id: 5,
    //         name: "BBQ Paneer Wrap",
    //         price: 199,
    //         img: img5, // Replace with actual image path
    //         time: 10,
    //         desc: "Grilled paneer with BBQ sauce, mixed veggies, and creamy dressing in a wrap."
    //       },
    //       {
    //         id: 6,
    //         name: "Mexican Bean Wrap",
    //         price: 179,
    //         img: img6, // Replace with actual image path
    //         time: 10,
    //         desc: "Spiced black beans, corn, and salsa wrapped in a tortilla, served with guacamole."
    //       },
    //       {
    //         id: 7,
    //         name: "Egg & Cheese Wrap",
    //         price: 159,
    //         img: img7, // Replace with actual image path
    //         time: 8,
    //         desc: "Scrambled eggs and melted cheese, wrapped in a tortilla with veggies."
    //       },
    //       {
    //         id: 8,
    //         name: "Paneer Tikka Wrap",
    //         price: 199,
    //         img: img8, // Replace with actual image path
    //         time: 12,
    //         desc: "Marinated paneer tikka with onions and peppers, wrapped with mint chutney."
    //       },
    //       {
    //         id: 9,
    //         name: "Falafel Wrap",
    //         price: 169,
    //         img: img9, // Replace with actual image path
    //         time: 10,
    //         desc: "Crispy falafels with fresh veggies and tahini sauce in a wrap."
    //       },
    //       {
    //         id: 10,
    //         name: "Chicken Caesar Wrap",
    //         price: 239,
    //         img: img10, // Replace with actual image path
    //         time: 12,
    //         desc: "Grilled chicken, romaine lettuce, and Caesar dressing wrapped in a tortilla."
    //       },
    //       {
    //         id: 11,
    //         name: "Teriyaki Chicken Wrap",
    //         price: 229,
    //         img: img11, // Replace with actual image path
    //         time: 15,
    //         desc: "Sweet and tangy teriyaki chicken with mixed vegetables wrapped in a tortilla."
    //       },
    //       {
    //         id: 12,
    //         name: "Shrimp & Avocado Wrap",
    //         price: 269,
    //         img: img12, // Replace with actual image path
    //         time: 15,
    //         desc: "Grilled shrimp with avocado and veggies wrapped in a soft tortilla."
    //       },
    //       {
    //         id: 13,
    //         name: "Sweet Chili Chicken Wrap",
    //         price: 219,
    //         img: img13, // Replace with actual image path
    //         time: 10,
    //         desc: "Spicy chicken with sweet chili sauce and fresh veggies wrapped in a tortilla."
    //       },
    //       {
    //         id: 14,
    //         name: "Greek Wrap",
    //         price: 199,
    //         img: img14, // Replace with actual image path
    //         time: 12,
    //         desc: "Grilled veggies, feta cheese, and olives wrapped in a pita bread."
    //       },
    //       {
    //         id: 15,
    //         name: "Buffalo Chicken Wrap",
    //         price: 239,
    //         img: img15, // Replace with actual image path
    //         time: 12,
    //         desc: "Spicy buffalo chicken with lettuce and ranch dressing wrapped in a tortilla."
    //       },{
    //         id: 1,
    //         name: "Kaju Anjeer Shake",
    //         price: 390,
    //         img: img1, // Replace with actual image path
    //         time: 20,
    //         desc: "Kaju anjeer shake, tasty and thick milkshake. Suitable for fasting [upwas]. No added preservatives, colors, chemicals and flavors."
    //       },
    //       {
    //         id: 2,
    //         name: "Mango Lassi",
    //         price: 250,
    //         img: img2, // Replace with actual image path
    //         time: 15,
    //         desc: "Refreshing mango yogurt drink blended with spices. Perfect for hot days!"
    //       },
    //       {
    //         id: 3,
    //         name: "Chocolate Milkshake",
    //         price: 300,
    //         img: img3, // Replace with actual image path
    //         time: 10,
    //         desc: "Rich and creamy chocolate milkshake topped with whipped cream."
    //       },
    //       {
    //         id: 4,
    //         name: "Strawberry Banana Smoothie",
    //         price: 320,
    //         img: img4, // Replace with actual image path
    //         time: 15,
    //         desc: "A delicious blend of strawberries and bananas, perfect for a healthy snack."
    //       },
    //       {
    //         id: 5,
    //         name: "Vanilla Almond Milkshake",
    //         price: 280,
    //         img: img5, // Replace with actual image path
    //         time: 10,
    //         desc: "Smooth and creamy vanilla shake made with almond milk and topped with crushed almonds."
    //       },
    //       {
    //         id: 6,
    //         name: "Pistachio Shake",
    //         price: 350,
    //         img: img6, // Replace with actual image path
    //         time: 15,
    //         desc: "A delightful shake made with pistachios, perfect for a refreshing treat."
    //       },
    //       {
    //         id: 7,
    //         name: "Mint Chocolate Chip Shake",
    //         price: 320,
    //         img: img7, // Replace with actual image path
    //         time: 10,
    //         desc: "Cool mint and rich chocolate blend into a refreshing shake."
    //       },
    //       {
    //         id: 8,
    //         name: "Coffee Milkshake",
    //         price: 330,
    //         img: img8, // Replace with actual image path
    //         time: 10,
    //         desc: "A delicious coffee-flavored shake for coffee lovers!"
    //       },
    //       {
    //         id: 9,
    //         name: "Peanut Butter Banana Shake",
    //         price: 350,
    //         img: img9, // Replace with actual image path
    //         time: 15,
    //         desc: "A healthy shake with peanut butter, bananas, and milk for an energy boost."
    //       },
    //       {
    //         id: 10,
    //         name: "Tropical Fruit Smoothie",
    //         price: 300,
    //         img: img10, // Replace with actual image path
    //         time: 15,
    //         desc: "A refreshing smoothie made with tropical fruits like pineapple and mango."
    //       },
    //       {
    //         id: 11,
    //         name: "Nutella Milkshake",
    //         price: 400,
    //         img: img11, // Replace with actual image path
    //         time: 10,
    //         desc: "Indulge in our creamy Nutella milkshake, topped with chocolate shavings."
    //       },
    //       {
    //         id: 12,
    //         name: "Caramel Shake",
    //         price: 350,
    //         img: img12, // Replace with actual image path
    //         time: 10,
    //         desc: "A rich shake infused with caramel flavor, perfect for a sweet treat."
    //       },
    //       {
    //         id: 13,
    //         name: "Avocado Smoothie",
    //         price: 400,
    //         img: img13, // Replace with actual image path
    //         time: 15,
    //         desc: "Creamy avocado smoothie, rich in healthy fats and delicious flavor."
    //       },
    //       {
    //         id: 14,
    //         name: "Coconut Water Shake",
    //         price: 250,
    //         img: img14, // Replace with actual image path
    //         time: 15,
    //         desc: "A refreshing shake made with fresh coconut water and tropical fruits."
    //       },
    //       {
    //         id: 15,
    //         name: "Blueberry Smoothie",
    //         price: 320,
    //         img: img15, // Replace with actual image path
    //         time: 15,
    //         desc: "Healthy and delicious smoothie made with fresh blueberries."
    //       },    {
    //         "id": 1,
    //         "name": "Chicken Biryani",
    //         "price": 299,
    //         "img": img1,
    //         "time": 40,
    //         "desc": "Fragrant basmati rice layered with succulent chicken cooked in rich spices."
    //     },
    //     {
    //         "id": 2,
    //         "name": "Mutton Biryani",
    //         "price": 399,
    //         "img": img2,
    //         "time": 45,
    //         "desc": "Tender mutton pieces cooked to perfection with aromatic spices and basmati rice."
    //     },
    //     {
    //         "id": 3,
    //         "name": "Veg Biryani",
    //         "price": 199,
    //         "img": img3,
    //         "time": 30,
    //         "desc": "A delightful mix of vegetables and spices layered with fragrant rice."
    //     },
    //     {
    //         "id": 4,
    //         "name": "Egg Biryani",
    //         "price": 249,
    //         "img": img4,
    //         "time": 35,
    //         "desc": "Boiled eggs cooked in spices and layered with basmati rice for a hearty meal."
    //     },
    //     {
    //         "id": 5,
    //         "name": "Prawn Biryani",
    //         "price": 450,
    //         "img": img5,
    //         "time": 40,
    //         "desc": "Aromatic basmati rice with prawns cooked in spices, garnished with fried onions."
    //     },
    //     {
    //         "id": 6,
    //         "name": "Kashmiri Biryani",
    //         "price": 320,
    //         "img": img6,
    //         "time": 50,
    //         "desc": "Rich and creamy biryani with dried fruits and nuts, a true Kashmiri delight."
    //     },
    //     {
    //         "id": 7,
    //         "name": "Hyderabadi Biryani",
    //         "price": 350,
    //         "img": img7,
    //         "time": 60,
    //         "desc": "Famous for its robust flavors, made with marinated meat and fragrant rice."
    //     },
    //     {
    //         "id": 8,
    //         "name": "Afghani Biryani",
    //         "price": 249,
    //         "img": img8,
    //         "time": 30,
    //         "desc": "Legendary for its rich taste & creamy texture, tender chicken marinated in fresh creamy yoghurt & spices is layered with aromatic basmati."
    //     },
    //     {
    //         "id": 9,
    //         "name": "Soya Biryani",
    //         "price": 220,
    //         "img": img1,
    //         "time": 35,
    //         "desc": "Flavorful soya chunks cooked with basmati rice and spices, a great vegetarian option."
    //     },
    //     {
    //         "id": 10,
    //         "name": "Cheesy Biryani",
    //         "price": 280,
    //         "img": img2,
    //         "time": 40,
    //         "desc": "A cheesy twist to the traditional biryani, made with creamy cheese sauce and rice."
    //     },
    //     {
    //         "id": 11,
    //         "name": "Bhookhad Biryani",
    //         "price": 500,
    //         "img": img3,
    //         "time": 60,
    //         "desc": "A spicy and flavorful biryani, best suited for those who can handle heat."
    //     },
    //     {
    //         "id": 12,
    //         "name": "Malai Biryani",
    //         "price": 340,
    //         "img": img4,
    //         "time": 50,
    //         "desc": "Rich biryani made with cream and mild spices for a luxurious taste."
    //     },
    //     {
    //         "id": 13,
    //         "name": "Seafood Biryani",
    //         "price": 450,
    //         "img": img5,
    //         "time": 45,
    //         "desc": "Combination of various seafoods, layered with spiced basmati rice."
    //     },
    //     {
    //         "id": 14,
    //         "name": "Tomato Biryani",
    //         "price": 200,
    //         "img": img6,
    //         "time": 30,
    //         "desc": "Unique biryani made with fresh tomatoes and spices, offering a tangy flavor."
    //     },
    //     {
    //         "id": 15,
    //         "name": "Paneer Biryani",
    //         "price": 260,
    //         "img": img7,
    //         "time": 35,
    //         "desc": "Delicious paneer cubes cooked with aromatic rice and spices, ideal for vegetarians."
    //     },
    //     {
    //         "id": 1,
    //         "name": "Penne Arrabbiata",
    //         "price": 199,
    //         "img": "img1",
    //         "time": 20,
    //         "desc": "Penne pasta in a spicy tomato sauce with garlic and chili flakes."
    //     },
    //     {
    //         "id": 2,
    //         "name": "Pasta Primavera",
    //         "price": 229,
    //         "img": "img2",
    //         "time": 25,
    //         "desc": "A colorful medley of seasonal vegetables tossed with pasta in olive oil."
    //     },
    //     {
    //         "id": 3,
    //         "name": "Cheesy Macaroni",
    //         "price": 179,
    //         "img": "img3",
    //         "time": 15,
    //         "desc": "Classic macaroni and cheese baked to perfection with a crispy topping."
    //     },
    //     {
    //         "id": 4,
    //         "name": "Spaghetti Carbonara",
    //         "price": 249,
    //         "img": "img4",
    //         "time": 20,
    //         "desc": "Spaghetti tossed in a creamy sauce with pancetta, eggs, and Parmesan cheese."
    //     },
    //     {
    //         "id": 5,
    //         "name": "Lasagna",
    //         "price": 299,
    //         "img": "img5",
    //         "time": 30,
    //         "desc": "Layers of pasta, rich meat sauce, and cheesy béchamel baked to perfection."
    //     },
    //     {
    //         "id": 6,
    //         "name": "Fettuccine Alfredo",
    //         "price": 239,
    //         "img": "img6",
    //         "time": 25,
    //         "desc": "Fettuccine pasta in a creamy Alfredo sauce with garlic and Parmesan."
    //     },
    //     {
    //         "id": 7,
    //         "name": "Veggie Pesto Pasta",
    //         "price": 219,
    //         "img": "img7",
    //         "time": 20,
    //         "desc": "Pasta tossed with fresh basil pesto and a mix of seasonal vegetables."
    //     },
    //     {
    //         "id": 8,
    //         "name": "Macaroni Salad",
    //         "price": 159,
    //         "img": "img8",
    //         "time": 10,
    //         "desc": "Chilled macaroni salad with a mix of veggies, mayonnaise, and herbs."
    //     },
    //     {
    //         "id": 9,
    //         "name": "Italiano Pasta",
    //         "price": 249,
    //         "img": "img9",
    //         "time": 20,
    //         "desc": "An Italian classic with an Indian twist. Onion, capsicum, paneer, mushroom."
    //     },
    //     {
    //         "id": 10,
    //         "name": "Seafood Pasta",
    //         "price": 349,
    //         "img": "img10",
    //         "time": 30,
    //         "desc": "Pasta tossed with shrimp, calamari, and a light garlic sauce."
    //     },
    //     {
    //         "id": 11,
    //         "name": "Baked Ziti",
    //         "price": 229,
    //         "img": "img11",
    //         "time": 25,
    //         "desc": "Ziti pasta baked with marinara sauce, ricotta, and mozzarella cheese."
    //     },
    //     {
    //         "id": 12,
    //         "name": "Pasta with Marinara Sauce",
    //         "price": 199,
    //         "img": "img12",
    //         "time": 15,
    //         "desc": "Classic spaghetti served with homemade marinara sauce."
    //     },
    //     {
    //         "id": 13,
    //         "name": "Pasta Puttanesca",
    //         "price": 239,
    //         "img": "img13",
    //         "time": 20,
    //         "desc": "Spaghetti in a spicy sauce made with tomatoes, olives, and capers."
    //     },
    //     {
    //         "id": 14,
    //         "name": "Creamy Mushroom Pasta",
    //         "price": 259,
    //         "img": "img14",
    //         "time": 25,
    //         "desc": "Pasta in a rich and creamy mushroom sauce with herbs."
    //     },
    //     {
    //         "id": 15,
    //         "name": "Spinach and Ricotta Ravioli",
    //         "price": 299,
    //         "img": "img15",
    //         "time": 30,
    //         "desc": "Ravioli stuffed with spinach and ricotta cheese, served in a light sauce."
    //     },{
    //         "id": 1,
    //         "name": "Chocolate Lava Cake",
    //         "price": 199,
    //         "img": "img1",
    //         "time": 20,
    //         "desc": "Warm chocolate cake with a molten chocolate center, served with vanilla ice cream."
    //     },
    //     {
    //         "id": 2,
    //         "name": "Strawberry Cheesecake",
    //         "price": 249,
    //         "img": "img2",
    //         "time": 25,
    //         "desc": "Creamy cheesecake topped with fresh strawberries on a buttery crust."
    //     },
    //     {
    //         "id": 3,
    //         "name": "Vanilla Cupcake",
    //         "price": 99,
    //         "img": "img3",
    //         "time": 10,
    //         "desc": "Moist vanilla cupcake topped with rich buttercream frosting."
    //     },
    //     {
    //         "id": 4,
    //         "name": "Tiramisu",
    //         "price": 229,
    //         "img": "img4",
    //         "time": 30,
    //         "desc": "Classic Italian dessert made with coffee-soaked ladyfingers and mascarpone cheese."
    //     },
    //     {
    //         "id": 5,
    //         "name": "Fruit Tart",
    //         "price": 199,
    //         "img": "img5",
    //         "time": 20,
    //         "desc": "A buttery tart filled with pastry cream and topped with fresh seasonal fruits."
    //     },
    //     {
    //         "id": 6,
    //         "name": "Chocolate Mousse",
    //         "price": 179,
    //         "img": "img6",
    //         "time": 15,
    //         "desc": "Rich and creamy chocolate mousse topped with whipped cream."
    //     },
    //     {
    //         "id": 7,
    //         "name": "Lemon Tart",
    //         "price": 159,
    //         "img": "img7",
    //         "time": 20,
    //         "desc": "Tangy lemon filling in a crispy tart shell, served with whipped cream."
    //     },
    //     {
    //         "id": 8,
    //         "name": "Pistachio Baklava",
    //         "price": 189,
    //         "img": "img8",
    //         "time": 15,
    //         "desc": "Layers of phyllo pastry filled with pistachios and sweetened with honey syrup."
    //     },
    //     {
    //         "id": 9,
    //         "name": "Red Velvet Cake",
    //         "price": 249,
    //         "img": "img9",
    //         "time": 25,
    //         "desc": "Moist red velvet cake layered with cream cheese frosting."
    //     },
    //     {
    //         "id": 10,
    //         "name": "Mango Pastry",
    //         "price": 149,
    //         "img": "img10",
    //         "time": 15,
    //         "desc": "Three layers of Mango mousse: white, milk, and dark chocolate mousse."
    //     },
    //     {
    //         "id": 11,
    //         "name": "Caramel Pudding",
    //         "price": 119,
    //         "img": "img11",
    //         "time": 10,
    //         "desc": "Smooth caramel pudding topped with caramel sauce."
    //     },
    //     {
    //         "id": 12,
    //         "name": "Banoffee Pie",
    //         "price": 199,
    //         "img": "img12",
    //         "time": 20,
    //         "desc": "A delicious pie made with bananas, cream, and toffee on a biscuit base."
    //     },
    //     {
    //         "id": 13,
    //         "name": "Almond Joy Cake",
    //         "price": 229,
    //         "img": "img13",
    //         "time": 30,
    //         "desc": "Moist chocolate cake filled with coconut and topped with almond flakes."
    //     },
    //     {
    //         "id": 14,
    //         "name": "Cheesecake Brownies",
    //         "price": 179,
    //         "img": "img14",
    //         "time": 25,
    //         "desc": "Rich brownie topped with a layer of creamy cheesecake."
    //     },
    //     {
    //         "id": 15,
    //         "name": "Mango Mousse",
    //         "price": 169,
    //         "img": "img15",
    //         "time": 15,
    //         "desc": "Light and fluffy mango mousse, perfect for mango lovers."
    //     },{
    //         "id": 1,
    //         "name": "Vanilla Ice Cream",
    //         "price": 150,
    //         "img": "img1",
    //         "time": 5,
    //         "desc": "Classic vanilla ice cream made with real vanilla beans."
    //     },
    //     {
    //         "id": 2,
    //         "name": "Chocolate Ice Cream",
    //         "price": 160,
    //         "img": "img2",
    //         "time": 5,
    //         "desc": "Rich chocolate ice cream with a deep cocoa flavor."
    //     },
    //     {
    //         "id": 3,
    //         "name": "Strawberry Ice Cream",
    //         "price": 170,
    //         "img": "img3",
    //         "time": 5,
    //         "desc": "Creamy strawberry ice cream made with fresh strawberries."
    //     },
    //     {
    //         "id": 4,
    //         "name": "Mint Chocolate Chip",
    //         "price": 180,
    //         "img": "img4",
    //         "time": 5,
    //         "desc": "Refreshing mint ice cream with chocolate chips."
    //     },
    //     {
    //         "id": 5,
    //         "name": "Cookies and Cream",
    //         "price": 190,
    //         "img": "img5",
    //         "time": 5,
    //         "desc": "Creamy vanilla ice cream mixed with chocolate sandwich cookie pieces."
    //     },
    //     {
    //         "id": 6,
    //         "name": "Mango Ice Cream",
    //         "price": 200,
    //         "img": "img6",
    //         "time": 5,
    //         "desc": "Delicious mango ice cream made with real mango pulp."
    //     },
    //     {
    //         "id": 7,
    //         "name": "Pistachio Ice Cream",
    //         "price": 210,
    //         "img": "img7",
    //         "time": 5,
    //         "desc": "Creamy pistachio ice cream with real pistachio nuts."
    //     },
    //     {
    //         "id": 8,
    //         "name": "Rocky Road Ice Cream",
    //         "price": 220,
    //         "img": "img8",
    //         "time": 5,
    //         "desc": "Chocolate ice cream with marshmallows and walnuts."
    //     },
    //     {
    //         "id": 9,
    //         "name": "Coffee Ice Cream",
    //         "price": 230,
    //         "img": "img9",
    //         "time": 5,
    //         "desc": "Rich coffee ice cream made with premium coffee beans."
    //     },
    //     {
    //         "id": 10,
    //         "name": "Butter Pecan Ice Cream",
    //         "price": 240,
    //         "img": "img10",
    //         "time": 5,
    //         "desc": "Creamy butter pecan ice cream with roasted pecans."
    //     },
    //     {
    //         "id": 11,
    //         "name": "Chocolate Chip Cookie Dough",
    //         "price": 250,
    //         "img": "img11",
    //         "time": 5,
    //         "desc": "Vanilla ice cream with chunks of cookie dough and chocolate chips."
    //     },
    //     {
    //         "id": 12,
    //         "name": "Neapolitan Ice Cream",
    //         "price": 260,
    //         "img": "img12",
    //         "time": 5,
    //         "desc": "Classic combination of chocolate, vanilla, and strawberry ice creams."
    //     },
    //     {
    //         "id": 13,
    //         "name": "Salted Caramel Ice Cream",
    //         "price": 270,
    //         "img": "img13",
    //         "time": 5,
    //         "desc": "Creamy caramel ice cream with a hint of sea salt."
    //     },
    //     {
    //         "id": 14,
    //         "name": "Lemon Sorbet",
    //         "price": 280,
    //         "img": "img14",
    //         "time": 5,
    //         "desc": "Refreshing lemon sorbet made with real lemon juice."
    //     },
    //     {
    //         "id": 15,
    //         "name": "Raspberry Ripple Ice Cream",
    //         "price": 290,
    //         "img": "img15",
    //         "time": 5,
    //         "desc": "Creamy vanilla ice cream swirled with raspberry sauce."
    //     },{
    //         "id": 1,
    //         "name": "Paneer Tikka",
    //         "price": 90,
    //         "img": "img12",
    //         "time": 15,
    //         "desc": "An Innovation To Our Paneer Pudina Tikka - Savour The Soft And Smooth Chunks Of Smokey Chutney Stuffed Paneer Tikka"
    //     },
    //     {
    //         "id": 2,
    //         "name": "Chicken Tikka",
    //         "price": 150,
    //         "img": "img1",
    //         "time": 20,
    //         "desc": "Tender pieces of chicken marinated in spices and grilled to perfection."
    //     },
    //     {
    //         "id": 3,
    //         "name": "Mutton Tikka",
    //         "price": 250,
    //         "img": "img2",
    //         "time": 25,
    //         "desc": "Succulent mutton pieces marinated in traditional spices and grilled."
    //     },
    //     {
    //         "id": 4,
    //         "name": "Fish Tikka",
    //         "price": 220,
    //         "img": "img3",
    //         "time": 20,
    //         "desc": "Marinated fish grilled with a smoky flavor."
    //     },
    //     {
    //         "id": 5,
    //         "name": "Tandoori Mushroom Tikka",
    //         "price": 140,
    //         "img": "img4",
    //         "time": 15,
    //         "desc": "Juicy mushrooms marinated in spices and grilled in a tandoor."
    //     },
    //     {
    //         "id": 6,
    //         "name": "Vegetable Tikka",
    //         "price": 80,
    //         "img": "img5",
    //         "time": 15,
    //         "desc": "Mixed seasonal vegetables marinated and grilled to perfection."
    //     },
    //     {
    //         "id": 7,
    //         "name": "Paneer Malai Tikka",
    //         "price": 110,
    //         "img": "img6",
    //         "time": 20,
    //         "desc": "Creamy paneer pieces marinated in malai and spices, grilled to perfection."
    //     },
    //     {
    //         "id": 8,
    //         "name": "Achari Chicken Tikka",
    //         "price": 170,
    //         "img": "img7",
    //         "time": 20,
    //         "desc": "Chicken marinated in achari spices and grilled."
    //     },
    //     {
    //         "id": 9,
    //         "name": "Tandoori Broccoli Tikka",
    //         "price": 130,
    //         "img": "img8",
    //         "time": 15,
    //         "desc": "Broccoli marinated in spices and grilled in a tandoor."
    //     },
    //     {
    //         "id": 10,
    //         "name": "Tandoori Prawns",
    //         "price": 300,
    //         "img": "img9",
    //         "time": 25,
    //         "desc": "Juicy prawns marinated in spices and grilled to perfection."
    //     },
    //     {
    //         "id": 11,
    //         "name": "Cheese Tikka",
    //         "price": 160,
    //         "img": "img10",
    //         "time": 20,
    //         "desc": "Soft cheese cubes marinated in spices and grilled."
    //     },
    //     {
    //         "id": 12,
    //         "name": "Tandoori Cauliflower Tikka",
    //         "price": 90,
    //         "img": "img11",
    //         "time": 15,
    //         "desc": "Cauliflower marinated and grilled, packed with flavors."
    //     },
    //     {
    //         "id": 13,
    //         "name": "Dahi Tikka",
    //         "price": 120,
    //         "img": "img12",
    //         "time": 15,
    //         "desc": "Yogurt-marinated pieces grilled to perfection."
    //     },
    //     {
    //         "id": 14,
    //         "name": "Paneer Tikka Skewers",
    //         "price": 130,
    //         "img": "img13",
    //         "time": 15,
    //         "desc": "Paneer cubes and vegetables grilled on skewers."
    //     },
    //     {
    //         "id": 15,
    //         "name": "Tikka Platter",
    //         "price": 400,
    //         "img": "img14",
    //         "time": 30,
    //         "desc": "A combination of various tikka dishes served on a platter."
    //     }
    
    
    // ]