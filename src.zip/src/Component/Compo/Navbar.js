import React from "react";

import { useSelector, useDispatch } from "react-redux";
import { Link } from "react-router-dom";

const App = () => {
  let names = useSelector((state) => state.cart);
  let dispatch = useDispatch();

  // let prices = names.reduce((summ, numm) => summ + numm.price, 0);
  let prices = names.reduce((numm, summ) => numm + summ.price  * summ.quantity, 0)

  return (
    <div className="two">
      {/* Navbar Start */}
      <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container-fluid">
          <a class="navbar-brand me-auto" href="#">
            <div className="ok"></div>
            
          </a>
          
          <div
            class="offcanvas offcanvas-end"
            tabindex="-1"
            id="offcanvasNavbar"
            aria-labelledby="offcanvasNavbarLabel"
          >
            <div class="offcanvas-header">
              {/* <h5 class="offcanvas-title" id="offcanvasNavbarLabel">
                Logo
              </h5> */}
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="offcanvas"
                aria-label="Close"
              ></button>
            </div>
            <div class="offcanvas-body">
              <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                <li class="nav-item">
                  <a
                    class="nav-link active mx-lg-2"
                    aria-current="page"
                    href="/"
                  >
                    Home
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link mx-lg-2" href="#about">
                    about us
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link mx-lg-2" href="#category">
                    category
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link mx-lg-2" href="#Product">
                    Products
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link mx-lg-2" href="#review">
                    review
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link mx-lg-2" href="#Contact">
                    Contact us
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link mx-lg-2" href="#">
                  Total Price:{prices}
                  </a>
                </li>
                
              </ul>
              
            </div>
          </div>
          <div>
          
          <i class="bi bi-search"></i>
          
          <Link to="/cart"><i class="bi bi-cart-fill">{names.length}{" "}</i></Link>
         
          </div>
          <a href="#" class="Login-button">Login</a>
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="offcanvas"
            data-bs-target="#offcanvasNavbar"
            aria-controls="offcanvasNavbar"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
        </div>
      </nav>
      {/* Navbar End */}

      
      
    </div>
  );
};

export default App;
