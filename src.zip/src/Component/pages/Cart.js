import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { remove, increment, decrement, clearCart } from '../store/Cartslice'; // Import clearCart action


const Cart = () => {
  const cartItems = useSelector((state) => state.cart);
  const dispatch = useDispatch();

  const handleRemove = (id) => {
    dispatch(remove(id));
  };

  const handleIncrement = (itemId) => {
    const item = cartItems.find((item) => item.id === itemId);
    if (item.quantity < 3) {
      dispatch(increment(itemId));
    } else {
      alert('You can only add a maximum of 3 items.');
    }
  };

  const handleDecrement = (itemId) => {
    dispatch(decrement(itemId));
  };

  const handleCheckout = () => {
    // Show thank you alert
    alert('Thank you for your purchase!');
    
    // Dispatch an action to clear the cart
    dispatch(clearCart());
  };

  const totalPrice = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0).toFixed(2);

  return (
    <div className="container my-4">
      <h2 className="text-center mb-4">Your Shopping Cart</h2>
      <div className="row">
        {cartItems.length === 0 ? (
          <div className="col-12 text-center">
            <p>Your cart is empty.</p>
          </div>
        ) : cartItems.length < 3 ? (
          <div className="col-12 text-center">
            <p>You need to add at least 3 items to your cart.</p>
          </div>
        ) : (
          <>
            {cartItems.map((item) => {
              let totalItemPrice = (item.price * item.quantity).toFixed(2);

              return (
                <div className="col-md-4" key={item.id}>
                  <div className="card mb-4 shadow-sm cart-card">
                    <img
                      src={item.img}
                      className="card-img-top img-fluid cart-image"
                      alt={item.name}
                    />
                    <div className="card-body">
                      <h5 className="card-title">{item.name}</h5>
                      <p className="card-text">
                        Price: <strong>{item.price} Rs</strong>
                      </p>
                      <p className="card-text">
                        Total: <strong>{totalItemPrice} Rs</strong>
                      </p>

                      <div className="d-flex justify-content-between align-items-center my-2">
                        <button
                          className="btn btn-outline-secondary w-100"
                          onClick={() => handleDecrement(item.id)}
                          disabled={item.quantity === 1}
                        >
                          -
                        </button>
                        <span className="mx-3">{item.quantity}</span>
                        <button
                          className="btn btn-outline-secondary w-100"
                          onClick={() => handleIncrement(item.id)}
                        >
                          +
                        </button>
                      </div>

                      <button
                        className="btn btn-danger mt-2 w-100"
                        onClick={() => handleRemove(item.id)}
                      >
                        Remove from Cart
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}

            {/* Total Price and Checkout Button */}
            <div className="col-12 text-center mt-4">
              <h4>Total Price: <strong>{totalPrice} Rs</strong></h4>
              <button
                className="btn btn-success mt-2"
                onClick={handleCheckout}
              >
                Checkout
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Cart;
