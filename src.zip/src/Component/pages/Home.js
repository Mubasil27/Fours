// import React from 'react'
// import image from '../Image/spaghetti-1932466.jpg'
// import About from './About'
// import Service from './Service'



// const Home = () => {
//   return (
//     <div>
//       {/* Home Start */}
      
//         <div className='relative'>
//         <img className='r' src={image} />
//         <div className='absolute'>
          
//           <h3 class="animate__animated animate__fadeInLeft">start your day <br/> with <span>Four'S</span></h3>
//           <a className='btn' class="animate__animated animate__fadeInLeft">get your now</a>
          
//         </div>
        
//      </div>
        
        
     
//       {/* Home End */}
//      <div className='fle'>
//        <div>
//        <i class="bi bi-truck"></i>
//        </div>
//        <div>FREE SHIPPING <br/>On orders over $100</div>
//        <div>
//        <i class="bi bi-clock"></i>
//        </div>
//        <div>
//        EXPRESS DELIVERY<br/>Available for Metro Areas*
//        </div>
//        <div>
//        <i class="bi bi-shop-window"></i>
//        </div>
//        <div>
//        PICKUP FROM STORE <br/>For your comfort
//        </div>
//        <div>
//        <i class="bi bi-lock"></i>
//        </div>
//        <div>
//        SECURED <br/>Shopping Site
//        </div>
//      </div>
//     </div>
//   )
// }

// export default Home
import React from 'react';
import { Link } from 'react-router-dom'; // Import Link for navigation
import image from '../Image/spaghetti-1932466.jpg';


const Home = () => {
  return (
    <div>
      {/* Home Start */}
      <div className='hero-section'>
        <img className='hero-image' src={image} alt="Delicious Spaghetti" />
        <div className='hero-overlay'>
          <h1 className="hero-title animate__animated animate__fadeInLeft">
            Start Your Day with <span className="highlight">Four'S</span>
          </h1>
          <Link className='btn animate__animated animate__fadeInUp' to="products"> {/* Updated to Link */}
            Get Yours Now
          </Link>
        </div>
      </div>

      {/* Features Section */}
      <div className='features'>
        <div className='feature-item'>
          <i className="bi bi-truck feature-icon"></i>
          <h4>Free Shipping</h4>
          <p>On orders over $100</p>
        </div>
        <div className='feature-item'>
          <i className="bi bi-clock feature-icon"></i>
          <h4>Express Delivery</h4>
          <p>Available for Metro Areas*</p>
        </div>
        <div className='feature-item'>
          <i className="bi bi-shop-window feature-icon"></i>
          <h4>Pickup from Store</h4>
          <p>For Your Comfort</p>
        </div>
        <div className='feature-item'>
          <i className="bi bi-lock feature-icon"></i>
          <h4>Secured Shopping</h4>
          <p>Your Safety is Our Priority</p>
        </div>
      </div>
    </div>
  );
}

export default Home;
