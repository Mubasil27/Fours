import React from 'react'
import {BrowserRouter,Routes,Route} from 'react-router-dom'
import Navbar from '../src/Component/Compo/Navbar'

import Footer from './Component/pages/Footer'
import { Provider } from 'react-redux'
import Store from './Component/store/Store'
import Cart from './Component/pages/Cart'
import Main from './Main'
import Burger from './Component/pages/Burger'




const App = () => {
 
  return (
    <div>
      <Provider store={Store}>
      <BrowserRouter>
      <Navbar/>
      <Routes>
        
       <Route path='/' element={<Main/>} />
        <Route path='/cart' element={<Cart/>} />
        <Route path='/burger' element={<Burger/>} />

      </Routes>
      </BrowserRouter>
      
      <Footer/>
     
      
     </Provider>
    
    
    
    </div>
  )
}

export default App
